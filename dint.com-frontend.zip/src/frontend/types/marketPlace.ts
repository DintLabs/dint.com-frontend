export interface IMarketPlace {
  totalPrice: number;
  itemId: number;
  seller: any;
  name: string;
  description: string;
  image: string;
}
