export interface IPurchases {
  totalPrice: number;
  price: number;
  itemId: number;
  name: string;
  description: string;
  image: string;
}
