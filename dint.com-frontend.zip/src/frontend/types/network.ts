export interface IFetchNetworkToken {
  Network: number;
  Network_Standard: string;
  Token_Address: string;
  tokenDecimal: number;
  walletAddress: string;
}
